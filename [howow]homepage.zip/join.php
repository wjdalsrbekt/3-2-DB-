<!DOCTYPE>
 
<html>
<head>
        <meta charset='utf-8'>
</head>
<body>
 
        <div align="center">
                <p>회원가입</p>
                <form method='get' action='join_action.php'>
                        <p>NAME: <input type="text" name="NAME"></p>
                        <p>GENDER: <input type="text" name="GENDER"></p>
                        <p>PHONE: <input type="text" name="PHONE"></p>
                        <p>CITY: <input type="text" name="CITY"></p>
                        <p>GU: <input type="text" name="GU"></p>
                        <p>DONG: <input type="text" name="DONG"></p>
                        
						<input type="submit" value="회원가입">
                </form>
        </div>
</body>
</html>

