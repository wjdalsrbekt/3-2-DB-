<?php
session_start();
include_once 'dbconfig.php';
$dbname="project";
mysqli_select_db($conn, $dbname) or die('DB selection failed');
        //입력 받은 id와 password
$id=$_GET['id'];
$pw=$_GET['pw'];
 
 //echo $id;
 //echo $pw;
$query2 = "select * from logindata2 where ID='$id'";
$result2 = $conn->query($query2);
  if(mysqli_num_rows($result2)==1) {
        $row=mysqli_fetch_assoc($result2);
 
                //비밀번호가 맞다면 세션 생성
        if($row['PW']==$pw){
                        $_SESSION['userid']=$id;
                        if(isset($_SESSION['userid'])){
                        ?>      <script>
                                        alert("로그인 되었습니다.");
                                        location.replace("./homepage.php");
                                </script>
<?php
                        }
      }
  }
        //아이디가 있는지 검사
$query = "select * from logindata where ID='$id'";
$result = $conn->query($query);
 
 
        //아이디가 있다면 비밀번호 검사
    if(mysqli_num_rows($result)==1) {
        $row=mysqli_fetch_assoc($result);
 
                //비밀번호가 맞다면 세션 생성
        if($row['PW']==$pw){
                        $_SESSION['userid']=$id;
                        if(isset($_SESSION['userid'])){
                        ?>      <script>
                                        alert("로그인 되었습니다.");
                                        location.replace("./homepage.php");
                                </script>
<?php
                        }
                        else{
                                echo "session fail";
                        }
                }
 
                else {
        ?>              <script>
                                alert("아이디 혹은 비밀번호가 잘못되었습니다.");
                                history.back();
                        </script>
        <?php
                }
 
        }
 
                else{
?>              <script>
                        alert("아이디 혹은 비밀번호가 잘못되었습니다.");
                        history.back();
                </script>
<?php
        }
 
 
?>